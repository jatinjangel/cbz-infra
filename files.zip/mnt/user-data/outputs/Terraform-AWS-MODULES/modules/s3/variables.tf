variable "bucket_name" {
  description = "S3 Bucket name"
  type        = string
}

variable "environment" {
  description = "Environment name"
  type        = string
}
